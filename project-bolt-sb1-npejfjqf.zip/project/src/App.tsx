import React, { useState } from 'react';
import { Search, Cloud, CloudRain, Sun, Wind, Droplets, CloudDrizzle, CloudSnow, CloudFog, CloudLightning, Calendar } from 'lucide-react';

interface WeatherData {
  city: string;
  temperature: number;
  description: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

interface ForecastData {
  date: string;
  temperature: number;
  description: string;
  icon: string;
}

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [forecast, setForecast] = useState<ForecastData[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const API_KEY = 'b572962750f6d8cc5d0d1f49e228be0f';

  const getWeatherIcon = (iconCode: string) => {
    const iconMap: { [key: string]: React.ReactNode } = {
      '01d': <Sun className="h-16 w-16 text-yellow-500" />,
      '01n': <Sun className="h-16 w-16 text-gray-400" />,
      '02d': <Cloud className="h-16 w-16 text-gray-500" />,
      '02n': <Cloud className="h-16 w-16 text-gray-600" />,
      '03d': <Cloud className="h-16 w-16 text-gray-500" />,
      '03n': <Cloud className="h-16 w-16 text-gray-600" />,
      '04d': <Cloud className="h-16 w-16 text-gray-500" />,
      '04n': <Cloud className="h-16 w-16 text-gray-600" />,
      '09d': <CloudDrizzle className="h-16 w-16 text-blue-500" />,
      '09n': <CloudDrizzle className="h-16 w-16 text-blue-600" />,
      '10d': <CloudRain className="h-16 w-16 text-blue-500" />,
      '10n': <CloudRain className="h-16 w-16 text-blue-600" />,
      '11d': <CloudLightning className="h-16 w-16 text-yellow-500" />,
      '11n': <CloudLightning className="h-16 w-16 text-yellow-600" />,
      '13d': <CloudSnow className="h-16 w-16 text-blue-300" />,
      '13n': <CloudSnow className="h-16 w-16 text-blue-400" />,
      '50d': <CloudFog className="h-16 w-16 text-gray-400" />,
      '50n': <CloudFog className="h-16 w-16 text-gray-500" />,
    };
    return iconMap[iconCode] || <Cloud className="h-16 w-16 text-gray-500" />;
  };

  const getForecastIcon = (iconCode: string) => {
    const iconMap: { [key: string]: React.ReactNode } = {
      '01d': <Sun className="h-8 w-8 text-yellow-500" />,
      '01n': <Sun className="h-8 w-8 text-gray-400" />,
      '02d': <Cloud className="h-8 w-8 text-gray-500" />,
      '02n': <Cloud className="h-8 w-8 text-gray-600" />,
      '03d': <Cloud className="h-8 w-8 text-gray-500" />,
      '03n': <Cloud className="h-8 w-8 text-gray-600" />,
      '04d': <Cloud className="h-8 w-8 text-gray-500" />,
      '04n': <Cloud className="h-8 w-8 text-gray-600" />,
      '09d': <CloudDrizzle className="h-8 w-8 text-blue-500" />,
      '09n': <CloudDrizzle className="h-8 w-8 text-blue-600" />,
      '10d': <CloudRain className="h-8 w-8 text-blue-500" />,
      '10n': <CloudRain className="h-8 w-8 text-blue-600" />,
      '11d': <CloudLightning className="h-8 w-8 text-yellow-500" />,
      '11n': <CloudLightning className="h-8 w-8 text-yellow-600" />,
      '13d': <CloudSnow className="h-8 w-8 text-blue-300" />,
      '13n': <CloudSnow className="h-8 w-8 text-blue-400" />,
      '50d': <CloudFog className="h-8 w-8 text-gray-400" />,
      '50n': <CloudFog className="h-8 w-8 text-gray-500" />,
    };
    return iconMap[iconCode] || <Cloud className="h-8 w-8 text-gray-500" />;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!city.trim()) return;

    setLoading(true);
    setError('');

    try {
      // Get current weather
      const weatherResponse = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
          city
        )}&appid=${API_KEY}&units=metric`,
        {
          headers: {
            'Accept': 'application/json',
          }
        }
      );

      if (!weatherResponse.ok) {
        if (weatherResponse.status === 404) {
          throw new Error('City not found. Please check the spelling and try again.');
        }
        throw new Error('Failed to fetch weather data. Please try again later.');
      }

      const weatherData = await weatherResponse.json();
      
      // Get 5-day forecast
      const forecastResponse = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(
          city
        )}&appid=${API_KEY}&units=metric`,
        {
          headers: {
            'Accept': 'application/json',
          }
        }
      );

      if (!forecastResponse.ok) {
        throw new Error('Failed to fetch forecast data. Please try again later.');
      }

      const forecastData = await forecastResponse.json();
      
      // Process current weather
      setWeather({
        city: weatherData.name,
        temperature: Math.round(weatherData.main.temp),
        description: weatherData.weather[0].description,
        humidity: weatherData.main.humidity,
        windSpeed: Math.round(weatherData.wind.speed * 3.6), // Convert m/s to km/h
        icon: weatherData.weather[0].icon,
      });

      // Process forecast data (one entry per day)
      const dailyForecasts = forecastData.list.reduce((acc: ForecastData[], item: any) => {
        const date = item.dt_txt.split(' ')[0];
        if (!acc.find(f => f.date === date)) {
          acc.push({
            date: date,
            temperature: Math.round(item.main.temp),
            description: item.weather[0].description,
            icon: item.weather[0].icon,
          });
        }
        return acc;
      }, []).slice(1, 6); // Skip today (already shown in current weather) and limit to 5 days

      setForecast(dailyForecasts);
      setError('');
    } catch (err) {
      setWeather(null);
      setForecast([]);
      setError(err instanceof Error ? err.message : 'Failed to fetch weather data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center p-4">
      <div className="bg-white/90 backdrop-blur-sm w-full max-w-2xl rounded-2xl shadow-xl p-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-6 flex items-center justify-center gap-2">
          <Cloud className="h-8 w-8 text-blue-500" />
          Weather Forecast
        </h1>

        <form onSubmit={handleSearch} className="mb-6">
          <div className="relative">
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="Enter city name"
              className="w-full px-4 py-2 pr-10 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              disabled={loading}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-blue-500 disabled:opacity-50"
            >
              <Search className="h-5 w-5" />
            </button>
          </div>
        </form>

        {loading && (
          <div className="text-center text-gray-600">Loading weather data...</div>
        )}

        {error && (
          <div className="text-center text-red-500 mb-4">{error}</div>
        )}

        {weather && !loading && (
          <>
            <div className="space-y-6 mb-8">
              <div className="text-center">
                <h2 className="text-2xl font-semibold text-gray-800">{weather.city}</h2>
                <div className="mt-4 flex justify-center">
                  {getWeatherIcon(weather.icon)}
                </div>
                <p className="text-5xl font-bold text-gray-800 mt-4">{weather.temperature}°C</p>
                <p className="text-xl text-gray-600 mt-2 capitalize">{weather.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 text-blue-600">
                    <Droplets className="h-5 w-5" />
                    <span>Humidity</span>
                  </div>
                  <p className="text-xl font-semibold mt-1">{weather.humidity}%</p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 text-blue-600">
                    <Wind className="h-5 w-5" />
                    <span>Wind Speed</span>
                  </div>
                  <p className="text-xl font-semibold mt-1">{weather.windSpeed} km/h</p>
                </div>
              </div>
            </div>

            {forecast.length > 0 && (
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  5-Day Forecast
                </h3>
                <div className="grid grid-cols-5 gap-2">
                  {forecast.map((day) => (
                    <div key={day.date} className="bg-blue-50 p-3 rounded-lg text-center">
                      <p className="text-sm font-medium text-gray-600">{formatDate(day.date)}</p>
                      <div className="flex justify-center my-2">
                        {getForecastIcon(day.icon)}
                      </div>
                      <p className="text-lg font-semibold text-gray-800">{day.temperature}°C</p>
                      <p className="text-xs text-gray-600 capitalize truncate" title={day.description}>
                        {day.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;